-- MySQL dump 10.13  Distrib 8.2.0, for macos12.6 (x86_64)
--
-- Host: localhost    Database: city_disaster_response
-- ------------------------------------------------------
-- Server version	8.2.0

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!50503 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*!40111 SET @OLD_SQL_NOTES=@@SQL_NOTES, SQL_NOTES=0 */;

--
-- Table structure for table `auth_group`
--

DROP TABLE IF EXISTS `auth_group`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(150) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `name` (`name`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group`
--

LOCK TABLES `auth_group` WRITE;
/*!40000 ALTER TABLE `auth_group` DISABLE KEYS */;
INSERT INTO `auth_group` VALUES (1,'group1');
/*!40000 ALTER TABLE `auth_group` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_group_permissions`
--

DROP TABLE IF EXISTS `auth_group_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_group_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `group_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_group_permissions_group_id_permission_id_0cd325b0_uniq` (`group_id`,`permission_id`),
  KEY `auth_group_permissions_group_id_b120cbf9` (`group_id`),
  KEY `auth_group_permissions_permission_id_84c5c92e` (`permission_id`)
) ENGINE=MyISAM AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_group_permissions`
--

LOCK TABLES `auth_group_permissions` WRITE;
/*!40000 ALTER TABLE `auth_group_permissions` DISABLE KEYS */;
INSERT INTO `auth_group_permissions` VALUES (1,1,4);
/*!40000 ALTER TABLE `auth_group_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_permission`
--

DROP TABLE IF EXISTS `auth_permission`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_permission` (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `content_type_id` int NOT NULL,
  `codename` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_permission_content_type_id_codename_01ab375a_uniq` (`content_type_id`,`codename`),
  KEY `auth_permission_content_type_id_2f476e4b` (`content_type_id`)
) ENGINE=MyISAM AUTO_INCREMENT=53 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_permission`
--

LOCK TABLES `auth_permission` WRITE;
/*!40000 ALTER TABLE `auth_permission` DISABLE KEYS */;
INSERT INTO `auth_permission` VALUES (1,'Can add log entry',1,'add_logentry'),(2,'Can change log entry',1,'change_logentry'),(3,'Can delete log entry',1,'delete_logentry'),(4,'Can view log entry',1,'view_logentry'),(5,'Can add permission',2,'add_permission'),(6,'Can change permission',2,'change_permission'),(7,'Can delete permission',2,'delete_permission'),(8,'Can view permission',2,'view_permission'),(9,'Can add group',3,'add_group'),(10,'Can change group',3,'change_group'),(11,'Can delete group',3,'delete_group'),(12,'Can view group',3,'view_group'),(13,'Can add user',4,'add_user'),(14,'Can change user',4,'change_user'),(15,'Can delete user',4,'delete_user'),(16,'Can view user',4,'view_user'),(17,'Can add content type',5,'add_contenttype'),(18,'Can change content type',5,'change_contenttype'),(19,'Can delete content type',5,'delete_contenttype'),(20,'Can view content type',5,'view_contenttype'),(21,'Can add session',6,'add_session'),(22,'Can change session',6,'change_session'),(23,'Can delete session',6,'delete_session'),(24,'Can view session',6,'view_session'),(25,'Can add record',7,'add_record'),(26,'Can change record',7,'change_record'),(27,'Can delete record',7,'delete_record'),(28,'Can view record',7,'view_record'),(29,'Can add recording',8,'add_recording'),(30,'Can change recording',8,'change_recording'),(31,'Can delete recording',8,'delete_recording'),(32,'Can view recording',8,'view_recording'),(33,'Can add incident',9,'add_incident'),(34,'Can change incident',9,'change_incident'),(35,'Can delete incident',9,'delete_incident'),(36,'Can view incident',9,'view_incident'),(37,'Can add incident',10,'add_incident'),(38,'Can change incident',10,'change_incident'),(39,'Can delete incident',10,'delete_incident'),(40,'Can view incident',10,'view_incident'),(41,'Can add incidents',11,'add_incidents'),(42,'Can change incidents',11,'change_incidents'),(43,'Can delete incidents',11,'delete_incidents'),(44,'Can view incidents',11,'view_incidents'),(45,'Can add image',12,'add_image'),(46,'Can change image',12,'change_image'),(47,'Can delete image',12,'delete_image'),(48,'Can view image',12,'view_image'),(49,'Can add user',13,'add_user'),(50,'Can change user',13,'change_user'),(51,'Can delete user',13,'delete_user'),(52,'Can view user',13,'view_user');
/*!40000 ALTER TABLE `auth_permission` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user`
--

DROP TABLE IF EXISTS `auth_user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `password` varchar(128) NOT NULL,
  `last_login` datetime(6) DEFAULT NULL,
  `is_superuser` tinyint(1) NOT NULL,
  `username` varchar(150) NOT NULL,
  `first_name` varchar(150) NOT NULL,
  `last_name` varchar(150) NOT NULL,
  `email` varchar(254) NOT NULL,
  `is_staff` tinyint(1) NOT NULL,
  `is_active` tinyint(1) NOT NULL,
  `date_joined` datetime(6) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `username` (`username`)
) ENGINE=MyISAM AUTO_INCREMENT=6 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user`
--

LOCK TABLES `auth_user` WRITE;
/*!40000 ALTER TABLE `auth_user` DISABLE KEYS */;
INSERT INTO `auth_user` VALUES (1,'pbkdf2_sha256$720000$BABdAbwuHFKXxNjM90WQfy$r52r4eKr2r5vLkBHOnY03YF5nzc8fZa2xIQyqibZ+Nc=','2024-01-23 15:40:49.836850',1,'root','','','123456@qq.com',1,1,'2020-04-16 07:23:50.418050'),(2,'pbkdf2_sha256$600000$R06UmscpHfaVRl4zRPbrGa$dzMm+gANP7Ahb5JySf4mr1DBhze8LkKH1tPlb04PooM=',NULL,0,'user1','','','',0,1,'2023-12-04 13:41:26.000000'),(3,'pbkdf2_sha256$720000$swsw5oIbnac2ndwogCmfnF$YuORxlBFtQZVVSgJx74eLnoAnf81VDSSE3uNbrm5+tM=',NULL,0,'user2','','','',0,1,'2023-12-05 15:07:00.000000'),(4,'pbkdf2_sha256$720000$y4J6exyxOtgG3rNJY38ZB6$IATqfRBsEchkpJzkT015VXQiKLmC7dpAmhTm2viaQlo=','2023-12-05 16:24:31.303614',0,'user3','','','',1,1,'2023-12-05 15:08:07.000000'),(5,'pbkdf2_sha256$720000$Ydt8kFPUDUqulDKA5JSevu$DVpsiw2jijVO5zO7lEO6pUp+CLjXwJD4GWzAXBBEKDM=',NULL,0,'user4','','','',0,1,'2023-12-05 16:23:44.254664');
/*!40000 ALTER TABLE `auth_user` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_groups`
--

DROP TABLE IF EXISTS `auth_user_groups`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_groups` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `group_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_groups_user_id_group_id_94350c0c_uniq` (`user_id`,`group_id`),
  KEY `auth_user_groups_user_id_6a12ed8b` (`user_id`),
  KEY `auth_user_groups_group_id_97559544` (`group_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_groups`
--

LOCK TABLES `auth_user_groups` WRITE;
/*!40000 ALTER TABLE `auth_user_groups` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_groups` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `auth_user_user_permissions`
--

DROP TABLE IF EXISTS `auth_user_user_permissions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `auth_user_user_permissions` (
  `id` int NOT NULL AUTO_INCREMENT,
  `user_id` int NOT NULL,
  `permission_id` int NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `auth_user_user_permissions_user_id_permission_id_14a6b632_uniq` (`user_id`,`permission_id`),
  KEY `auth_user_user_permissions_user_id_a95ead1b` (`user_id`),
  KEY `auth_user_user_permissions_permission_id_1fbb5f2c` (`permission_id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `auth_user_user_permissions`
--

LOCK TABLES `auth_user_user_permissions` WRITE;
/*!40000 ALTER TABLE `auth_user_user_permissions` DISABLE KEYS */;
/*!40000 ALTER TABLE `auth_user_user_permissions` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_admin_log`
--

DROP TABLE IF EXISTS `django_admin_log`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_admin_log` (
  `id` int NOT NULL AUTO_INCREMENT,
  `action_time` datetime(6) NOT NULL,
  `object_id` longtext,
  `object_repr` varchar(200) NOT NULL,
  `action_flag` smallint unsigned NOT NULL,
  `change_message` longtext NOT NULL,
  `content_type_id` int DEFAULT NULL,
  `user_id` int NOT NULL,
  PRIMARY KEY (`id`),
  KEY `django_admin_log_content_type_id_c4bce8eb` (`content_type_id`),
  KEY `django_admin_log_user_id_c564eba6` (`user_id`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_admin_log`
--

LOCK TABLES `django_admin_log` WRITE;
/*!40000 ALTER TABLE `django_admin_log` DISABLE KEYS */;
INSERT INTO `django_admin_log` VALUES (10,'2023-12-05 15:08:49.651200','4','user3',2,'[{\"changed\": {\"fields\": [\"Staff status\"]}}]',4,1),(9,'2023-12-05 15:08:07.944055','4','user3',1,'[{\"added\": {}}]',4,1),(8,'2023-12-05 15:07:10.514524','3','user2',2,'[]',4,1),(7,'2023-12-05 15:07:00.618666','3','user2',1,'[{\"added\": {}}]',4,1),(5,'2023-12-04 13:41:26.705894','2','user1',1,'[{\"added\": {}}]',4,1),(6,'2023-12-04 13:41:52.132312','2','user1',2,'[]',4,1),(11,'2023-12-05 16:23:05.045620','1','group1',1,'[{\"added\": {}}]',3,1),(12,'2023-12-05 16:23:18.369380','1','group1',2,'[]',3,1),(13,'2023-12-05 16:23:44.622448','5','user4',1,'[{\"added\": {}}]',4,1);
/*!40000 ALTER TABLE `django_admin_log` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_content_type`
--

DROP TABLE IF EXISTS `django_content_type`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_content_type` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app_label` varchar(100) NOT NULL,
  `model` varchar(100) NOT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `django_content_type_app_label_model_76bd3d3b_uniq` (`app_label`,`model`)
) ENGINE=MyISAM AUTO_INCREMENT=14 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_content_type`
--

LOCK TABLES `django_content_type` WRITE;
/*!40000 ALTER TABLE `django_content_type` DISABLE KEYS */;
INSERT INTO `django_content_type` VALUES (1,'admin','logentry'),(2,'auth','permission'),(3,'auth','group'),(4,'auth','user'),(5,'contenttypes','contenttype'),(6,'sessions','session'),(7,'record','record'),(8,'record','recording'),(9,'urban_app','incident'),(10,'core_app','incident'),(11,'core_app','incidents'),(12,'core_app','image'),(13,'core_app','user');
/*!40000 ALTER TABLE `django_content_type` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_migrations`
--

DROP TABLE IF EXISTS `django_migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_migrations` (
  `id` int NOT NULL AUTO_INCREMENT,
  `app` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `applied` datetime(6) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=22 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_migrations`
--

LOCK TABLES `django_migrations` WRITE;
/*!40000 ALTER TABLE `django_migrations` DISABLE KEYS */;
INSERT INTO `django_migrations` VALUES (1,'contenttypes','0001_initial','2020-04-16 07:23:14.158005'),(2,'auth','0001_initial','2020-04-16 07:23:15.244100'),(3,'admin','0001_initial','2020-04-16 07:23:16.734115'),(4,'admin','0002_logentry_remove_auto_add','2020-04-16 07:23:17.068223'),(5,'admin','0003_logentry_add_action_flag_choices','2020-04-16 07:23:17.082184'),(6,'contenttypes','0002_remove_content_type_name','2020-04-16 07:23:17.264699'),(7,'auth','0002_alter_permission_name_max_length','2020-04-16 07:23:17.379390'),(8,'auth','0003_alter_user_email_max_length','2020-04-16 07:23:17.549932'),(9,'auth','0004_alter_user_username_opts','2020-04-16 07:23:17.560904'),(10,'auth','0005_alter_user_last_login_null','2020-04-16 07:23:17.644681'),(11,'auth','0006_require_contenttypes_0002','2020-04-16 07:23:17.646677'),(12,'auth','0007_alter_validators_add_error_messages','2020-04-16 07:23:17.657645'),(13,'auth','0008_alter_user_username_max_length','2020-04-16 07:23:17.698567'),(14,'auth','0009_alter_user_last_name_max_length','2020-04-16 07:23:17.766387'),(15,'auth','0010_alter_group_name_max_length','2020-04-16 07:23:17.855118'),(16,'auth','0011_update_proxy_permissions','2020-04-16 07:23:17.870076'),(17,'sessions','0001_initial','2020-04-16 07:23:17.998733'),(18,'record','0001_initial','2020-04-28 08:28:05.360903'),(19,'auth','0012_alter_user_first_name_max_length','2023-12-01 09:34:02.800884'),(20,'core_app','0001_initial','2023-12-06 14:19:38.951913'),(21,'core_app','0002_alter_incident_images','2023-12-06 14:19:38.973650');
/*!40000 ALTER TABLE `django_migrations` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `django_session`
--

DROP TABLE IF EXISTS `django_session`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `django_session` (
  `session_key` varchar(40) NOT NULL,
  `session_data` longtext NOT NULL,
  `expire_date` datetime(6) NOT NULL,
  PRIMARY KEY (`session_key`),
  KEY `django_session_expire_date_a5c62663` (`expire_date`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `django_session`
--

LOCK TABLES `django_session` WRITE;
/*!40000 ALTER TABLE `django_session` DISABLE KEYS */;
INSERT INTO `django_session` VALUES ('23movmqap4gcky0dttecsp9oofucjifi','ZTg1MWU4MGQ0NDNkZTY0MjhhNzBkN2M4MmYwMDZlNzdjYzI3Y2YwOTp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyODQ1MzI2MWNjZWRmMjE2Yzg0MDhjZjc2MmFjZTNiNGFhYjdiYWI3Iiwic2ltcGxldWlfMjAyMDA0MTYiOnRydWV9','2020-04-30 07:37:13.560993'),('by9ocnd7zl2gipikq90xqpbdj8aregst','NjI2OTgxMDQ0YTVhMDRjMjA3MjEyNGZjMjg2MjkzZjdhMjA5NTI2Njp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyODQ1MzI2MWNjZWRmMjE2Yzg0MDhjZjc2MmFjZTNiNGFhYjdiYWI3Iiwic2ltcGxldWlfMjAyMDA0MjgiOnRydWUsInNpbXBsZXVpXzIwMjAwNDI5Ijp0cnVlfQ==','2020-05-13 06:48:55.137459'),('deyzp33judrpm5yf5wtb20w5c0ma30jv','N2JmZGIyYTIwNmQ0OGRhOWEwNWQ5MmIxMzc0NWNmYzhkZmJiNDYzZDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyODQ1MzI2MWNjZWRmMjE2Yzg0MDhjZjc2MmFjZTNiNGFhYjdiYWI3Iiwic2ltcGxldWlfMjAyMDA0MjkiOnRydWV9','2020-05-13 07:37:15.628815'),('5mmy6yp0afw81fptkdnilx1bv4c57d1z','NDExNWIxMDM5OGZmOWJiYjdmOTYyNmE1NmYzN2Q3ODkwZDA2ZjBhNDp7Il9hdXRoX3VzZXJfaWQiOiIxIiwiX2F1dGhfdXNlcl9iYWNrZW5kIjoiZGphbmdvLmNvbnRyaWIuYXV0aC5iYWNrZW5kcy5Nb2RlbEJhY2tlbmQiLCJfYXV0aF91c2VyX2hhc2giOiIyODQ1MzI2MWNjZWRmMjE2Yzg0MDhjZjc2MmFjZTNiNGFhYjdiYWI3Iiwic2ltcGxldWlfMjAyMDA1MDkiOnRydWV9','2020-05-23 06:03:30.175311'),('qowzzrublu6j7y5x0r05z1abj0968hpb','.eJx9kclugzAURX8FeR3moSK7dlN1kU2lrpoIeQxuwbZss4gi_r22SEUgw-7pvutzbDiDBg62bQZDdcMJ2IIUbK4zBPEvFX5BfqA4yghLYTVHka9El62JdpLQ7u3SXQBaaFp3uk4KmNeYoowVWZkndckoRjCtMprVDDEXlVWOihfC0qqqSlYWOSGE5RAjikrsoT0Vg3Gs7_MeQKX2YBu4wZn2YOMmAXs6Za8uk5rbU-C3VFiOoeVSTD2O_eR7DJqAwdDfMzQtpx2ZGr1_jfEdr5q5X65obiH_jGkz6G6-WezzeFpQTvwiTZJs3AQL8LuWg7oPtm3YcWPvsY_-1A08Hw_LIF3bdvCOKzSy48Qbe6hCxcXKGGOpaeM-e9xKD1o6irXjkyqp7TPNoDoJyUOLvgLMnnLt-RCYE_eHn5kIN6qDp4eqI7VLzOyrxgMY_wDibPy1:1rAWna:N0OzMR4ikYyECcRJVwxgkbNTFFG9Pfd8oi91Uf3g2lw','2023-12-19 14:53:22.768259'),('q7xc4683i8kv7kt7c9n32ea95x45civ8','.eJx9kT1vgzAURf8K8hw-nAD52Nql6pClUqcmQg_bBLdgW7YZooj_XlukItAk2-Pdyzk2XFABna2LzjBdcIp2CKPF7a4E8sOED-g3iJOMiBRW8zLyleiammgvKWter90JoAZTeyxNckoAl8kSkrLa4vUmXREMWUndRDd5VqWbVbJ2j7hKWM7SBMotpixLM7ytUg9tmeiMY31dDgiUOqBd4AZnOqCFmwS0bNi9uJ3U3J4DnzJhOQHLpRh6nPjJ9yowQQWhP2doas4aOjRafxvjO141cj9d0fyH_DGGpNPNeLLY7-MhYJz6ACfJsl8EE_Cblp26D7Z12HBj77FP_q1_8FV_nC7w3LaHO67QyIZTb2xBhYqLmTEmUrPCffa4lh40daRzxwdTUttnmk41EuhDi74BjJ5s7nkXhFP3h5-ZKDeqgfND1YnZKWb05f0R9b_sG_vr:1rAY8P:mPw_52o0BOiACBGdJj_T4tkkmrxrB9qLJoYlgnuzrM0','2023-12-19 16:18:57.282415'),('w1vafmr9nhhbe5btcc0tdfurmupmi3wd','.eJx9kbtuwyAUhl_FYo7vtyZbu1QdslTq1ETWMZCY1gYEeIgiv3tBTuXYuWxH5__5PrDPqILeNFWvqaoYQRuUodX1rgb8S7kLyA_wowiw4EaxOnCV4JLqYCsIbd8u3RmgAd3Y03UeFRhoWZM4SteEvOB1lJWA67SgJMUkT4qYlhnQPIsjXCRk7apJUUBa07rEDtpR3mvL-j7vEEi5QxvPDta0Qys7cejouHu1O6GYOXkupdwwDIYJPvYYdpPrHUB7B_DdPX3dMNqSsdG512jXcaqJ-2WL-hbyzxiTXrXTzUK3D8eAMuKCOIqSYeXNwO9K9PI-2DR-y7S5xz66UzfwdNjPF_HStoU7Ll-LlhFn7ED6kvGFMcRC0cp-9rARDjR3ZEvHJ5VCmWeaXrYCyEOLugJMnnzp-eCYEfuHn5kI07KF00PVkZo5ZvIVwx4Nf9o1_Kk:1rBHAz:OWSYoIDkoMJD_2lqJsJZO7F8pSG_Sdv-3FcWUCfOVq4','2023-12-21 16:24:37.123250'),('fff7ejwj5jafrjo8ajv77g37q1rc7q7o','.eJx9kbtuwyAUhl_FYo7vtyZbu1QdslTq1ETWMZCY1gYEeIgiv3tBTuXYuWxH5__5PrDPqILeNFWvqaoYQRuUodX1rgb8S7kLyA_wowiw4EaxOnCV4JLqYCsIbd8u3RmgAd3Y03UeFRhoWZM4SteEvOB1lJWA67SgJMUkT4qYlhnQPIsjXCRk7apJUUBa07rEDtpR3mvL-j7vEEi5QxvPDta0Qys7cejouHu1O6GYOXkupdwwDIYJPvYYdpPrHUB7B_DdPX3dMNqSsdG512jXcaqJ-2WL-hbyzxiTXrXTzUK3D8eAMuKCOIqSYeXNwO9K9PI-2DR-y7S5xz66UzfwdNjPF_HStoU7Ll-LlhFn7ED6kvGFMcRC0cp-9rARDjR3ZEvHJ5VCmWeaXrYCyEOLugJMnnzp-eCYEfuHn5kI07KF00PVkZo5ZvIVwx4Nf9o1_Kk:1rAXfS:o1K0_VgPzBRQ9muSYUMRD2piDxFpMKq8-PsVwvmBkNQ','2023-12-19 15:49:02.636543'),('enhr2whaxxx00rgue4w4naelxga74pwn','.eJx9kT1vgzAURf8K8hw-nAD52Nql6pClUqcmQg_bBLdgW7YZooj_XlukItAk2-Pdyzk2XFABna2LzjBdcIp2CKPF7a4E8sOED-g3iJOMiBRW8zLyleiammgvKWter90JoAZTeyxNckoAl8kSkrLa4vUmXREMWUndRDd5VqWbVbJ2j7hKWM7SBMotpixLM7ytUg9tmeiMY31dDgiUOqBd4AZnOqCFmwS0bNi9uJ3U3J4DnzJhOQHLpRh6nPjJ9yowQQWhP2doas4aOjRafxvjO141cj9d0fyH_DGGpNPNeLLY7-MhYJz6ACfJsl8EE_Cblp26D7Z12HBj77FP_q1_8FV_nC7w3LaHO67QyIZTb2xBhYqLmTEmUrPCffa4lh40daRzxwdTUttnmk41EuhDi74BjJ5s7nkXhFP3h5-ZKDeqgfND1YnZKWb05f0R9b_sG_vr:1rBHPY:EjsoQuvgxAhC0p1BNrvjX9XqtE82WftSnaFv-HqKbyk','2023-12-21 16:39:40.962881'),('49luhaeqcokqicu63z42y1wm5alte8zr','.eJx9kT1vgzAURf8K8hw-nAD52Nql6pClUqcmQg_bBLdgW7YZooj_XlukItAk2-Pdyzk2XFABna2LzjBdcIp2CKPF7a4E8sOED-g3iJOMiBRW8zLyleiammgvKWter90JoAZTeyxNckoAl8kSkrLa4vUmXREMWUndRDd5VqWbVbJ2j7hKWM7SBMotpixLM7ytUg9tmeiMY31dDgiUOqBd4AZnOqCFmwS0bNi9uJ3U3J4DnzJhOQHLpRh6nPjJ9yowQQWhP2doas4aOjRafxvjO141cj9d0fyH_DGGpNPNeLLY7-MhYJz6ACfJsl8EE_Cblp26D7Z12HBj77FP_q1_8FV_nC7w3LaHO67QyIZTb2xBhYqLmTEmUrPCffa4lh40daRzxwdTUttnmk41EuhDi74BjJ5s7nkXhFP3h5-ZKDeqgfND1YnZKWb05f0R9b_sG_vr:1rUr9f:CYHyZEIYqs2OZ3l__siVSA0vB_TcykQkmczaVcOH4zM','2024-02-13 16:40:11.480872');
/*!40000 ALTER TABLE `django_session` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `incident`
--

DROP TABLE IF EXISTS `incident`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `incident` (
  `id` int NOT NULL AUTO_INCREMENT,
  `location` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `images` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `description` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `incident_type` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `occur_time` timestamp NULL DEFAULT NULL,
  `status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `traffic_status` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `extrainfo` json DEFAULT NULL,
  `scale_impact` varchar(255) DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=17 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `incident`
--

LOCK TABLES `incident` WRITE;
/*!40000 ALTER TABLE `incident` DISABLE KEYS */;
INSERT INTO `incident` VALUES (12,'3 Meadow Park Ave, Whitehall, Dublin 14, D14 A0F9爱尔兰','incident_images/images_1.jpeg','earthquake','Earthquake','2023-12-06 00:00:00','active','crowded',NULL,'Severe'),(13,'3 Meadow Park Ave, Whitehall, Dublin 14, D14 A0F9爱尔兰','incident_images/images.jpeg','fire','Fire','2023-12-06 00:00:00','active','crowded',NULL,'Severe'),(14,'3 Meadow Park Ave, Whitehall, Dublin 14, D14 A0F9爱尔兰','incident_images/download_1.jpeg','flood','Flood','2023-12-06 00:00:00','active','crowded',NULL,'Severe'),(15,'3 Meadow Park Ave, Whitehall, Dublin 14, D14 A0F9爱尔兰','incident_images/download.jpeg','wildfire','Wildfire','2023-12-06 00:00:00','active','crowded',NULL,'Severe'),(16,'3 Meadow Park Ave, Whitehall, Dublin 14, D14 A0F9爱尔兰','incident_images/download_2.jpeg','cyclones','Cyclones','2023-12-06 00:00:00','active','crowded',NULL,'Severe');
/*!40000 ALTER TABLE `incident` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `record_record`
--

DROP TABLE IF EXISTS `record_record`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `record_record` (
  `id` int NOT NULL AUTO_INCREMENT,
  `record_url` varchar(100) NOT NULL,
  `datetime` date DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record_record`
--

LOCK TABLES `record_record` WRITE;
/*!40000 ALTER TABLE `record_record` DISABLE KEYS */;
INSERT INTO `record_record` VALUES (2,'static/video/2020-04-27.mp4','2020-04-27'),(6,'static/video/2023-11-29.mp4','2023-11-29');
/*!40000 ALTER TABLE `record_record` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `record_recording`
--

DROP TABLE IF EXISTS `record_recording`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `record_recording` (
  `id` int NOT NULL AUTO_INCREMENT,
  PRIMARY KEY (`id`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `record_recording`
--

LOCK TABLES `record_recording` WRITE;
/*!40000 ALTER TABLE `record_recording` DISABLE KEYS */;
/*!40000 ALTER TABLE `record_recording` ENABLE KEYS */;
UNLOCK TABLES;

--
-- Table structure for table `user`
--

DROP TABLE IF EXISTS `user`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!50503 SET character_set_client = utf8mb4 */;
CREATE TABLE `user` (
  `id` int NOT NULL AUTO_INCREMENT,
  `email` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `role` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `password` varchar(255) CHARACTER SET utf8mb4 COLLATE utf8mb4_0900_ai_ci DEFAULT NULL,
  `extrainfo` json DEFAULT NULL,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE=InnoDB AUTO_INCREMENT=3 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_0900_ai_ci ROW_FORMAT=DYNAMIC;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `user`
--

LOCK TABLES `user` WRITE;
/*!40000 ALTER TABLE `user` DISABLE KEYS */;
INSERT INTO `user` VALUES (1,'2222@qq.com',NULL,NULL,NULL),(2,'112@qq.com',NULL,NULL,NULL);
/*!40000 ALTER TABLE `user` ENABLE KEYS */;
UNLOCK TABLES;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*!40111 SET SQL_NOTES=@OLD_SQL_NOTES */;

-- Dump completed on 2024-02-08 13:54:10
